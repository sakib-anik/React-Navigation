export const ADD_TO_CART='add_to_cart';
export const REMOVE_FROM_CART='remove_from_cart';
export const USER_LIST ='user_list';
export const SET_USER_DATA='set_user_data';